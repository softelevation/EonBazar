import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Keyboard, ScrollView } from 'react-native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import { useDispatch, useSelector } from 'react-redux';
import { images } from '../../assets';
import Footer from '../../common/footer';
import Header from '../../common/header';
import Toast from '../../common/toast';
import {
  Block,
  Button,
  CustomButton,
  ImageComponent,
  Input,
  Text,
} from '../../components';
import Checkbox from '../../components/checkbox';
import { paymentRequest } from '../../redux/action';
import {
  strictValidArray,
  strictValidArrayWithLength,
} from '../../utils/commonUtils';
import { config } from '../../utils/config';

const initialState = {
  cards: false,
  cash: false,
};
const PaymentMethod = ({
  route: {
    params: { item },
  },
}) => {
  const nav = useNavigation();
  const [discount, setdiscount] = useState(false);
  const [instruction, setinstruction] = useState(false);
  const [toggleCheckBox, setToggleCheckBox] = useState(initialState);
  const [terms, setTerms] = useState([]);
  const [termsToggle, setTermsToggle] = useState(false);
  const isLoad = useSelector((state) => state.payment.loading);
  const dispatch = useDispatch();
  const [couponCode, setCouponCode] = useState('')

  const { cards, cash } = toggleCheckBox;
  const { addressInformation } = item;
  const { shipping_address } = addressInformation;
  const paymentMethod = useSelector(
    (v) => v.shipping.shippingDetails.data.payment_methods,
  );

  useEffect(() => {
    termsCondition();
  }, []);

  const termsCondition = async () => {
    const token = '5q0h1829ixf2vdm57k6g3qtzd88wkvr2';
    const headers = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + token,
    };
    axios({
      method: 'get',
      url: 'http://stage.eonbazar.com/rest/V1/carts/licence',
      headers,
    }).then((res) => setTerms(res.data));
  };

  const onSubmit = () => {
    const data = {
      method: cards,
      po_number: '',
      agreement_id: terms[0].agreement_id,
    };

    setTimeout(() => {
      Toast.show('Order place successfully...');
    }, 3000);

    dispatch(paymentRequest(data));
  };



  const applyCoupon = async (couponCode) => {

    Keyboard.dismiss()

    if (termsToggle == false) {
      Toast.show('Please check terms and conditions');
    }
    else if (cards == false) {
      Toast.show('Please select payment option');
    }
    else if (couponCode == null || couponCode == '') {
      Toast.show('Please enter discount coupon');
    } else {
      const token = await AsyncStorage.getItem('token');
      const headers = {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + token,
      };
      return fetch(
        `${config.Api_Url}/V1/carts/mine/coupons/${couponCode}`,
        {
          method: 'PUT',
          headers: headers,
        },
      )
        .then((r) => r.json())
        .then((r) => {
          console.log("====", r)

          if (r == true) {
            setTimeout(() => {
              Toast.show('Coupon apply successfully');
            }, 1000);
            onSubmit()
          } else {
            setTimeout(() => {
              Toast.show(r.message);
            }, 1000);
          }

        })
        .catch((error) => {
          console.error(error);
          return [];
        });

    }
  };



  return (
    <Block>
      <Header leftIcon={false} />
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Text margin={[hp(2), 0, 0, 0]} semibold transform="uppercase" center>
          Payment Method
        </Text>
        <Block white padding={[hp(3)]} margin={[hp(2), wp(5)]}>
          {paymentMethod.map((a) => {
            return (
              <>
                <Block margin={[hp(1), 0, 0]} row center flex={false}>
                  <Checkbox
                    checkboxStyle={{ height: 20, width: 20 }}
                    label={a.title}
                    checked={a.code === cards}
                    onChange={(newValue) => setToggleCheckBox({ cards: a.code })}
                    labelStyle={{ fontSize: 12, color: '#818991' }}
                  />
                </Block>

                {a.code === cards && (
                  <>
                    <Block flex={false} margin={[0, wp(8)]}>
                      <Text height={20} grey size={12}>
                        {shipping_address.firstname} {shipping_address.lastname}
                      </Text>
                      <Text height={20} grey size={12}>
                        {shipping_address.street[0]}{' '}
                        {shipping_address.street[1] || ''}
                      </Text>
                      <Text height={20} grey size={12}>
                        {shipping_address.telephone}
                      </Text>
                    </Block>

                    {strictValidArrayWithLength(terms) && (
                      <Block margin={[hp(1), 0, 0]} row center flex={false}>
                        <Checkbox
                          checkboxStyle={{ height: 20, width: 20 }}
                          label={terms[0].checkbox_text}
                          checked={termsToggle}
                          onChange={(newValue) => setTermsToggle(!termsToggle)}
                          labelStyle={{ fontSize: 12, color: '#818991' }}
                          checkedImage={images.checkbox_icon}
                          uncheckedImage={images.uncheckbox_icon}
                        />
                      </Block>
                    )}

                    <CustomButton
                      onPress={() => setinstruction(!instruction)}
                      center
                      row
                      margin={[hp(1), 0]}
                      flex={false}>
                      <Text
                        height={20}
                        margin={[0, wp(1), 0, 0]}
                        grey
                        size={12}>
                        Special Instruction
                      </Text>
                      <ImageComponent
                        name={instruction ? 'up_arrow_icon' : 'down_arrow_icon'}
                        height="10"
                        width="10"
                      />
                    </CustomButton>
                    {instruction && (
                      <>
                        <Input
                          placeholder="Enter Your comment"
                          multiline={true}
                          numberOfLines={4}
                          style={{ height: hp(8) }}
                        />
                      </>
                    )}
                  </>
                )}
              </>
            );
          })}


          <Button
            disabled={!termsToggle || !cards}
            isLoading={isLoad}
            onPress={() => onSubmit()}
            color="secondary">
            Place Order
          </Button>
          <CustomButton
            row
            center
            padding={[hp(1), 0, 0]}
            // margin={[hp(1), 0, 0]}
            onPress={() => setdiscount(!discount)}
            flex={false}>
            <Text link margin={[0, wp(1), 0, 0]} grey size={12}>
              Apply Discount Code
            </Text>
            <ImageComponent
              name={discount ? 'up_arrow_icon' : 'down_arrow_icon'}
              height="10"
              width="10"
            />
          </CustomButton>
          {discount && (
            <>
              <Input
                value={couponCode}
                onChangeText={text => setCouponCode(text)}
                label="Discount Coupon" />
              <Button onPress={() => applyCoupon(couponCode)} color="secondary">Apply Discount</Button>
            </>
          )}
        </Block>
        <Footer images={false} />
      </ScrollView>
    </Block>
  );
};

export default PaymentMethod;
